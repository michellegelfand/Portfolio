#include "handleton.hpp"
#include "logger.hpp"

using namespace ilrd;


init_handleton(Logger)

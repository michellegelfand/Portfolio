
/**
 * File:   monitor.cpp
 * Date:   07.11.19
 * Author: Inbar Duek
 * */

#include "../include/monitor.hpp"

namespace ilrd
{

Monitor::~Monitor() { }


} // namespace ilrd

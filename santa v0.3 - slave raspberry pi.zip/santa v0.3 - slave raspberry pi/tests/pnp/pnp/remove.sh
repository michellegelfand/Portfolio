#!/bin/bash
#shared object:

rm *.o
rm *.out
rm *.so
rm *.txt
